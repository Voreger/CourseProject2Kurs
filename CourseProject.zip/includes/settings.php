<?php
$db_host = "localhost";
$db_user = "root";
$db_password = "12345678";
$db_database = "course_project";
$tablename = "data";